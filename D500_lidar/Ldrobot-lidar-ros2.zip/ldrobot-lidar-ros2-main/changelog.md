CHANGELOG
=========

v0.1.0
------
* ROS2 Foxy and Ubuntu 20.04
* First working version of the node based on ROS2 lifecycle architecture
* Python launch scripts
* Parameters customization
* Examples
